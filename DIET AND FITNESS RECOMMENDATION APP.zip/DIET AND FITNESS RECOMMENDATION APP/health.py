from dotenv import load_dotenv
import os
import streamlit as st
import google.generativeai as genai
import requests

# Load environment variables
load_dotenv()

# Configure Generative AI API
api_key = os.getenv("GOOGLE_API_KEY")

if api_key:
    genai.configure(api_key=api_key)  # Configure with the API key
else:
    st.error("Google API Key is missing. Please check your .env file.")

# Function to get the user's location using browser geolocation or IP-based fallback
def get_user_location():
    # Attempt to get the user's location via browser-based geolocation
    location = st.query_params.get('location', None)
    
    if location:
        lat, lon = location[0].split(',')
        return float(lat), float(lon)
    else:
        # Fallback to IP-based geolocation if browser geolocation is not available
        try:
            response = requests.get("http://ipinfo.io/json")
            data = response.json()
            loc = data['loc'].split(',')
            return float(loc[0]), float(loc[1])
        except requests.exceptions.RequestException:
            st.write("Could not detect your location. Please try again.")
            return None, None

# Function to generate a link to Google Maps for nearby hospitals and specialists
def get_nearby_hospitals_and_specialists(latitude, longitude, condition):
    if latitude and longitude:
        google_maps_url = f"https://www.google.com/maps/search/hospitals/@{latitude},{longitude},15z"
        specialist_url = f"https://www.google.com/maps/search/{condition}+specialist/@{latitude},{longitude},15z"
        return google_maps_url, specialist_url
    else:
        return None, None

# Function to generate meal suggestions based on the user's input
def generate_meal_plan(activity_level, dietary_preference, time_of_day, custom_input=None):
    try:
        prompt = f"Create a meal plan based on the following:\nActivity Level: {activity_level}\nDietary Preference: {dietary_preference}\nTime of Day: {time_of_day}\n"
        
        if custom_input:
            prompt += f"Additional preferences: {custom_input}\n"
        
        prompt += "Provide three meal options."
        
        model = genai.GenerativeModel('gemini-pro')
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        return f"An error occurred while generating the meal plan: {e}"

# Function to generate an answer dynamically using the Generative AI API
def generate_answer(question):
    try:
        prompt = f"Answer the following question accurately and concisely:\n{question}"
        model = genai.GenerativeModel("gemini-pro")
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        return f"An error occurred while generating the answer: {e}"

# Symptom Checker feature
def symptom_checker():
    st.subheader("Symptom Checker")

    # Step 1: Input Age and Gender
    age = st.number_input("Enter your age:", min_value=0, max_value=120, step=1)
    gender = st.radio("Select your gender:", ("Male", "Female"))

    if st.button("Continue", key="symptom_step1"):
        if age > 0:
            st.session_state["symptom_step"] = 2
        else:
            st.error("Please enter a valid age.")

    # Step 2: Input Symptoms
    if st.session_state.get("symptom_step") == 2:
        symptoms = st.text_area("List your symptoms (comma-separated):", placeholder="e.g., fever, headache, nausea")
        if st.button("Find Possible Conditions", key="symptom_step2"):
            if symptoms.strip():
                st.session_state["symptom_step"] = 3
                st.session_state["symptoms"] = symptoms
            else:
                st.error("Please enter your symptoms.")

    # Step 3: Show Possible Conditions
    if st.session_state.get("symptom_step") == 3:
        st.write("Analyzing your symptoms...")
        possible_conditions, treatments = generate_possible_conditions_and_treatments(st.session_state["symptoms"])
        st.subheader("Possible Conditions")
        st.write(possible_conditions)
        st.subheader("Treatment Options")
        st.write(treatments)

        if st.button("Emergency Help Needed?", key="emergency_button"):
            st.session_state["symptom_step"] = 4

    # Step 4: Emergency Response
    if st.session_state.get("symptom_step") == 4:
        st.warning("If this is a medical emergency, please call your local emergency services immediately.")
        
        # Get the user's location for nearby hospitals and specialists
        latitude, longitude = get_user_location()
        
        if latitude and longitude:
            st.write(f"Your location: Latitude {latitude}, Longitude {longitude}")
            st.write("Would you like to locate the nearest hospital and specialists?")
            
            # Add buttons for hospitals and specialists
            if st.button("Find Nearby Hospitals"):
                hospital_link, specialist_link = get_nearby_hospitals_and_specialists(latitude, longitude, st.session_state["symptoms"])
                if hospital_link:
                    st.write(f"[Click here to view hospitals near you]( {hospital_link} )")
                else:
                    st.error("Could not find nearby hospitals.")
                
            if st.button("Find Nearby Specialists"):
                hospital_link, specialist_link = get_nearby_hospitals_and_specialists(latitude, longitude, st.session_state["symptoms"])
                if specialist_link:
                    st.write(f"[Click here to view specialists near you]( {specialist_link} )")
                else:
                    st.error("Could not find nearby specialists.")
        else:
            st.error("Could not detect your location. Please try again.")

# Function to generate possible conditions and treatments (mock implementation)
def generate_possible_conditions_and_treatments(symptoms):
    try:
        prompt = f"Based on the following symptoms, list possible conditions and their treatments:\n{symptoms}\nProvide the top 5 possible conditions with treatment options."
        model = genai.GenerativeModel("gemini-pro")
        response = model.generate_content(prompt)
        return response.text.split("\n")[0], response.text.split("\n")[1:]  # Example: split conditions and treatments
    except Exception as e:
        return f"An error occurred while analyzing the symptoms: {e}", []

# Function to handle login
def handle_login():
    if "login_status" not in st.session_state:
        st.session_state["login_status"] = False

    if not st.session_state["login_status"]:
        st.title("Health & Meal Planner")
        st.subheader("Login")

        name = st.text_input("Enter your name")
        email = st.text_input("Enter your email")

        if st.button("Login"):
            if name and email:
                st.session_state["login_status"] = True
                st.session_state["name"] = name
                st.session_state["email"] = email
                st.session_state["current_page"] = "main"
                st.session_state["redirected"] = True  # Indicate that the login was successful
            else:
                st.error("Please fill in all fields.")
    else:
        if st.session_state.get("current_page") == "main":
            main_page()

# Function for the main page
def main_page():
    st.title("Welcome to Health & Meal Planner")
    st.write(f"Hello, {st.session_state['name']}!")

    option = st.selectbox("Choose an action:", ["Ask Questions", "Meal Planner", "Symptom Checker"])

    if option == "Ask Questions":
        question = st.text_input("Enter your question:")
        if st.button("Submit Question"):
            if question.strip():
                answer = generate_answer(question)
                st.subheader("Answer:")
                st.write(answer)
            else:
                st.error("Please enter a valid question.")

    elif option == "Meal Planner":
        meal_planner()

    elif option == "Symptom Checker":
        symptom_checker()

# Meal planner function
def meal_planner():
    st.subheader("Meal Planner")

    activity_level = st.selectbox("Select your activity level:", ["Sedentary", "Moderate", "Active"])
    dietary_preference = st.selectbox("Select your dietary preference:", ["Vegetarian", "Vegan", "Non-Vegetarian", "Gluten-Free", "Keto", "Other"])
    time_of_day = st.selectbox("Select the time of day for meal planning:", ["Morning", "Afternoon", "Evening"])

    custom_input = st.text_area("Type your additional meal preferences here:", placeholder="For example: I like spicy food or avoid dairy")

    query_input = st.text_input("Or ask a meal-related question:")

    if st.button("Generate Meal Plan"):
        if query_input:
            meal_plan = generate_meal_plan(activity_level, dietary_preference, time_of_day, query_input)
            st.subheader("Your Meal Plan:")
            st.write(meal_plan)
        else:
            meal_plan = generate_meal_plan(activity_level, dietary_preference, time_of_day, custom_input)
            st.subheader("Your Meal Plan:")
            st.write(meal_plan)

# Function to apply custom CSS for styling
def apply_custom_css():
    st.markdown("""
        <style>
            .stTextInput>div>div>input {
                font-size: 18px;
                height: 40px;
                border-radius: 10px;
                padding: 10px;
            }
            .stButton>button {
                background-color: #FF6F61;
                color: white;
                border-radius: 10px;
                padding: 10px;
                font-size: 16px;
            }
            .stButton>button:hover {
                background-color: #E55A4C;
            }
            .stSelectbox>div>div>div>input {
                font-size: 18px;
                padding: 10px;
            }
        </style>
    """, unsafe_allow_html=True)

# Apply custom CSS to improve the UI
apply_custom_css()

# Start the app with login page
handle_login()