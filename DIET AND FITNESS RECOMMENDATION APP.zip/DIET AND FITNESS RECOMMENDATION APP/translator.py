import openai
import pyttsx3
import streamlit as st
from dotenv import load_dotenv
from googletrans import Translator
import threading

# Load environment variables
load_dotenv()

# Initialize text-to-speech engine
engine = pyttsx3.init()

# Function to convert text to speech (in a separate thread)
def speak_text(text):
    def run_speech():
        engine.say(text)
        engine.runAndWait()

    # Start the speech in a separate thread
    speech_thread = threading.Thread(target=run_speech)
    speech_thread.start()

# Function to translate text
def translate_text(text, target_language='en'):
    translator = Translator()
    translated = translator.translate(text, dest=target_language)
    return translated.text

# Function to interact with GPT or similar model
def get_dynamic_answer(query):
    # Set up the OpenAI API key (ensure it is set in .env file)
    openai.api_key = os.getenv("OPENAI_API_KEY")

    # Call OpenAI GPT or similar model for dynamic responses
    response = openai.Completion.create(
        model="text-davinci-003",  # You can use GPT-3 or GPT-4 model
        prompt=query,
        max_tokens=150
    )
    answer = response.choices[0].text.strip()
    return answer

# Initialize Streamlit app
st.set_page_config(page_title="Indian Languages Translator")
st.header("Indian Languages Translator")

# Add custom CSS to style the page
st.markdown("""
    <style>
        .stButton>button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 24px;
            font-size: 16px;
            cursor: pointer;
        }
        .stButton>button:hover {
            background-color: #45a049;
        }
        .stTextInput>div>div>input {
            font-size: 16px;
            padding: 12px;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        h1 {
            color: #2c3e50;
        }
    </style>
""", unsafe_allow_html=True)

# Input field for text to translate
input_text = st.text_input("Enter text to translate or ask a question: ", key="input_text")

# Regional language options (ISO 639-1 codes for Indian languages)
indian_languages = [
    ("English", "en"),
    ("Hindi", "hi"),
    ("Bengali", "bn"),
    ("Telugu", "te"),
    ("Tamil", "ta"),
    ("Marathi", "mr"),
    ("Gujarati", "gu"),
    ("Malayalam", "ml"),
    ("Kannada", "kn"),
    ("Punjabi", "pa"),
    ("Odia", "or"),
    ("Assamese", "as"),
    ("Urdu", "ur"),
    ("Nepali", "ne"),
    ("Sinhala", "si"),
    ("Bodo", "bo"),
    ("Kashmiri", "ks"),
    ("Konkani", "br")
]

# Target language selection
target_language = st.selectbox("Select target language for translation", indian_languages, format_func=lambda x: x[0])
target_language_code = target_language[1]  # Get the code for selected language

# Button for submitting translation request
submit_button = st.button("Submit")

# Handle translation and dynamic response functionality
if submit_button and input_text:
    # Get the dynamic answer from GPT or a similar model
    dynamic_answer = get_dynamic_answer(input_text)
    
    # Translate the dynamic answer to the target language
    translated_answer = translate_text(dynamic_answer, target_language_code)

    # Display the translated answer and speak it
    st.subheader(f"Translated Answer in {target_language[0]}:")
    st.write(translated_answer)
    speak_text(translated_answer)
