import streamlit as st
import matplotlib.pyplot as plt

# BMI Calculation function
def calculate_bmi(height, weight):
    # BMI formula: weight (kg) / height (m)^2
    height_m = height / 100  # Convert cm to meters
    bmi = weight / (height_m ** 2)
    return bmi

# Create BMI gauge chart
def create_bmi_gauge(bmi):
    # Gauge categories
    categories = ['Underweight', 'Normal', 'Overweight', 'Obesity', 'Severe Obesity']
    ranges = [16, 18.5, 25, 30, 40]
    colors = ['blue', 'green', 'yellow', 'orange', 'red']

    # Create the gauge
    fig, ax = plt.subplots(figsize=(6, 3))

    for i in range(len(ranges) - 1):
        ax.barh(
            [1],
            width=(ranges[i + 1] - ranges[i]),
            left=ranges[i],
            height=0.5,
            color=colors[i],
            edgecolor='black',
        )

    # Add the BMI marker
    ax.scatter([bmi], [1], color='black', zorder=5)
    ax.text(bmi, 1.2, f"BMI: {bmi:.1f}", ha='center', fontsize=10, color='black')

    # Format the plot
    ax.set_xlim([10, 40])
    ax.set_yticks([])
    ax.set_xticks(ranges)  # Ensure the ticks match the ranges
    ax.set_xticklabels(categories, fontsize=10, color='black', rotation=45)  # Match the number of labels

    ax.spines['left'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['top'].set_visible(False)
    ax.spines['bottom'].set_visible(False)

    ax.set_title("BMI Categories", fontsize=12, pad=20, color='black')
    plt.box(False)

    return fig

# Waist-to-Hip Ratio Calculation function
def calculate_waist_to_hip_ratio(waist_size, hip_size):
    ratio = waist_size / hip_size
    return ratio

# Waist-to-Hip Ratio Visualization
def create_waist_to_hip_visualization(ratio, sex):
    # Healthy threshold values for waist-to-hip ratio
    if sex == "Male":
        healthy_threshold = 0.90
    else:
        healthy_threshold = 0.85
    
    fig, ax = plt.subplots(figsize=(6, 3))
    
    # Create bars for the waist-to-hip ratio and healthy threshold
    ax.barh(['Waist-to-Hip Ratio'], [ratio], color='blue', edgecolor='black', height=0.5)
    ax.barh(['Waist-to-Hip Ratio'], [healthy_threshold], color='lightgreen', edgecolor='black', height=0.5, left=ratio)
    
    # Add text indicating the ratio and threshold
    ax.text(ratio, 0, f"Your Ratio: {ratio:.2f}", ha='right', fontsize=10, color='black')
    ax.text(healthy_threshold, 0, f"Healthy Threshold: {healthy_threshold}", ha='left', fontsize=10, color='green')

    # Format the plot
    ax.set_xlim([0, 2])
    ax.set_title("Waist-to-Hip Ratio", fontsize=12, pad=20, color='black')
    ax.set_yticks([])
    ax.set_xlabel("Ratio")

    plt.box(False)

    return fig

# Healthy Weight Plan Ideal Weight Calculation
def calculate_ideal_weight(height):
    # Healthy BMI range: 18.5 to 24.9
    min_bmi = 18.5
    max_bmi = 24.9

    # Calculate ideal weight based on height (in meters)
    height_m = height / 100  # Convert height to meters
    ideal_weight_min = min_bmi * (height_m ** 2)
    ideal_weight_max = max_bmi * (height_m ** 2)
    
    return ideal_weight_min, ideal_weight_max

# Healthy Weight Plan Visualization with Ideal Weight
def create_weight_plan_visual(age, activity_level, weight_goal, current_weight, height):
    ideal_weight_min, ideal_weight_max = calculate_ideal_weight(height)
    
    target_weight = (ideal_weight_min + ideal_weight_max) / 2  # Averaging ideal weight range

    fig, ax = plt.subplots(figsize=(6, 3))

    ax.barh(['Current Weight'], [current_weight], color='blue', edgecolor='black', height=0.5)
    ax.barh(['Ideal Weight Range'], [ideal_weight_max - ideal_weight_min], left=ideal_weight_min, color='lightgreen', edgecolor='black', height=0.5)

    ax.set_xlim([current_weight - 10, current_weight + 10])
    ax.set_title(f"Healthy Weight Plan Goal: {weight_goal}", fontsize=12, pad=20, color='black')
    ax.set_yticks([])
    ax.set_xlabel("Weight (kg)")

    ax.text(current_weight, 0, f"Current Weight: {current_weight} kg", ha='right', fontsize=10, color='black')
    ax.text(target_weight, 0.5, f"Target Weight: {target_weight:.1f} kg", ha='left', fontsize=10, color='black')

    plt.box(False)

    return fig

# Main function
def main():
    st.title("Health Calculators")

    # Input fields for BMI
    st.subheader("BMI Calculator")
    height = st.number_input("Enter your height (cm):", min_value=50, max_value=300, value=170)
    weight = st.number_input("Enter your weight (kg):", min_value=20, max_value=500, value=70)
    
    if st.button("Calculate BMI"):
        if height and weight:
            bmi = calculate_bmi(height, weight)
            st.write(f"Your BMI is: {bmi:.1f}")
            
            # Display BMI Gauge chart
            fig = create_bmi_gauge(bmi)
            st.pyplot(fig)

            # Provide feedback on BMI
            if bmi < 18.5:
                st.write("You are in the 'Underweight' category.")
            elif 18.5 <= bmi < 24.9:
                st.write("You are in the 'Normal' category.")
            elif 25 <= bmi < 29.9:
                st.write("You are in the 'Overweight' category.")
            else:
                st.write("You are in the 'Obesity' category.")

    # Waist-to-hip calculator (optional)
    st.subheader("Waist-to-Hip Calculator")
    sex = st.selectbox("Select your sex:", ["Male", "Female"])
    waist_size = st.number_input("Enter your waist size (inches):", min_value=10, max_value=60, value=30)
    hip_size = st.number_input("Enter your hip size (inches):", min_value=20, max_value=60, value=35)

    if st.button("Calculate Waist-to-Hip Ratio"):
        if waist_size and hip_size:
            ratio = calculate_waist_to_hip_ratio(waist_size, hip_size)
            st.write(f"Your Waist-to-Hip ratio is: {ratio:.2f}")
            
            # Display Waist-to-Hip Ratio Visualization
            fig = create_waist_to_hip_visualization(ratio, sex)
            st.pyplot(fig)

            if sex == "Male":
                if ratio > 0.90:
                    st.write("You are at a higher risk for health problems related to abdominal fat.")
                else:
                    st.write("Your waist-to-hip ratio is in the healthy range.")
            else:
                if ratio > 0.85:
                    st.write("You are at a higher risk for health problems related to abdominal fat.")
                else:
                    st.write("Your waist-to-hip ratio is in the healthy range.")

    # Healthy Weight Plan Calculator
    st.subheader("Healthy Weight Plan")
    age = st.number_input("Enter your age (years):", min_value=1, max_value=120, value=25)
    activity_level = st.selectbox("Select your activity level:", ["Sedentary", "Lightly Active", "Moderately Active", "Very Active"])
    weight_goal = st.selectbox("Select your weight goal:", ["Maintain Weight", "Lose Weight", "Gain Weight"])
    current_weight = st.number_input("Enter your current weight (kg):", min_value=20, max_value=500, value=70)
    
    if st.button("Calculate Healthy Weight Plan"):
        if age and activity_level and weight_goal:
            st.write(f"Age: {age} years")
            st.write(f"Activity Level: {activity_level}")
            st.write(f"Weight Goal: {weight_goal}")
            
            # Create weight plan visualization
            fig = create_weight_plan_visual(age, activity_level, weight_goal, current_weight, height)
            st.pyplot(fig)

if __name__ == "__main__":
    main()
