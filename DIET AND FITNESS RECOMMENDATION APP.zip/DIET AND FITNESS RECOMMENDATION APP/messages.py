import streamlit as st
from twilio.rest import Client
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import io

# Twilio account SID and Auth Token
account_sid = "ACfb01d46e5ce63023780793e26ec74228"
auth_token = "47f4d1bd5c8b8a9966e73beb1c5e05cb"
twilio_number = "+16202999768"  # Replace with your actual Twilio phone number

# Function to send SMS
def send_sms(phone_number, message):
    client = Client(account_sid, auth_token)
    message = client.messages.create(
        body=message,
        from_=twilio_number,
        to=phone_number
    )
    return message.sid

# Streamlit UI
st.title("Health and Fitness Assistant")

# User input for phone number and nutrition goal
phone_number = "+91 9840694099"  # Fixed phone number for sending the message

# Nutrition goal selection
goal = st.radio("What is your nutrition goal?", 
                ["Weight Loss", "Muscle Gain", "General Well-being", "Boost Immunity"])

# Dietary preferences selection
st.write("Select your dietary preferences:")
preferences = st.multiselect("Preferences:", 
                             ["Vegetarian", "Vegan", "Low Carb", "Keto", "Paleo", "Gluten-Free"])

# Daily calorie target input
calories = st.number_input("Enter your daily calorie target (kcal):", min_value=1000, max_value=4000, step=100)

# Diet Plan Message
def generate_diet_plan():
    if goal == "Weight Loss":
        return ("Focus on high-protein, low-carb meals. Include leafy greens, lean meats, "
                "healthy fats like avocado, and drink plenty of water. Suggested timings: "
                "Breakfast - 8 AM, Lunch - 1 PM, Dinner - 7 PM. Substitutes: Use cauliflower rice instead of white rice.")
    elif goal == "Muscle Gain":
        return ("Increase protein intake. Include eggs, chicken, fish, and legumes in your meals. "
                "Suggested timings: Breakfast - 8 AM, Snack - 11 AM, Lunch - 1 PM, Post-Workout - 4 PM, Dinner - 7 PM. "
                "Substitutes: Quinoa or chickpeas for protein.")
    elif goal == "General Well-being":
        return ("Maintain a balanced diet with fruits, vegetables, whole grains, and moderate protein intake. "
                "Suggested timings: Breakfast - 8 AM, Snack - 10 AM, Lunch - 1 PM, Snack - 4 PM, Dinner - 7 PM. "
                "Substitutes: Almond milk instead of regular milk.")
    elif goal == "Boost Immunity":
        return ("Focus on vitamin-rich foods like citrus fruits, spinach, and yogurt. Include ginger and turmeric in your diet. "
                "Suggested timings: Breakfast - 8 AM, Snack - 10 AM, Lunch - 1 PM, Dinner - 7 PM. "
                "Substitutes: Lemon water instead of sugary drinks.")
    else:
        return "Please select a valid goal."

# Function to generate a detailed PDF report
def generate_pdf(diet_plan_message):
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=letter)
    
    c.setFont("Helvetica", 12)
    c.drawString(100, 750, "Health and Fitness Diet Plan")
    c.drawString(100, 730, f"Goal: {goal}")
    c.drawString(100, 710, f"Preferences: {', '.join(preferences)}" if preferences else "Preferences: N/A")
    c.drawString(100, 690, f"Daily Calorie Target: {calories} kcal")
    c.drawString(100, 670, "-----------------------------------------")
    
    c.drawString(100, 650, "Diet Plan:")
    c.drawString(100, 630, diet_plan_message)
    
    c.save()
    
    buffer.seek(0)
    return buffer

# Generate nutrition plan
if st.button("Get Nutrition Plan"):
    if preferences or goal or calories:
        st.markdown('<h3>Your Personalized Nutrition Plan:</h3>', unsafe_allow_html=True)
        
        # Display the diet plan recommendation based on the goal
        diet_plan_message = generate_diet_plan()

        # Display calorie target message
        diet_plan_message += f"\nTarget: {calories} kcal/day. Plan your meals to include sufficient macros and micronutrients."
        
        st.write(diet_plan_message)  # Display the message on Streamlit page

        # Generate PDF
        pdf_buffer = generate_pdf(diet_plan_message)
        
        # Provide the PDF for download
        st.download_button(
            label="Download Your Full Diet Plan (PDF)",
            data=pdf_buffer,
            file_name="Diet_Plan.pdf",
            mime="application/pdf"
        )

        # Send SMS with the diet plan (optional)
        if phone_number:
            # Ensure phone number is in correct format
            if not phone_number.startswith("+"):
                formatted_phone_number = "+" + phone_number
            else:
                formatted_phone_number = phone_number

            # Send the message via Twilio
            try:
                send_sms(formatted_phone_number, diet_plan_message)
                st.success(f"Diet plan message sent to {formatted_phone_number}!")
            except Exception as e:
                st.error(f"Error sending SMS: {str(e)}")
        else:
            st.warning("Please enter a valid phone number.")
    else:
        st.warning("Please provide your preferences or goals to generate a nutrition plan.")
